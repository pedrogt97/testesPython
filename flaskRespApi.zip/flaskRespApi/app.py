from flask import Flask
from flask import request
import json

baseDeDados = 'base.json'

# COMENTAR SEÇÃO ABAIXO CASO QUEIRA PERSISTIR OS DADOS ( NÃO COMENTAR NA PRIMEIRA EXECUÇÃO )
Usuarios = {'Usuarios':[]}
arquivo = open(baseDeDados, "w")
json.dump(Usuarios, arquivo)
arquivo.close()
# FIM SEÇÃO

app = Flask(__name__)
# @app.route('/hello/', methods=['GET', 'POST'])
# def welcome():
#     return "Hello World!"

@app.route('/usuario/',methods = ['POST'])
def insereUsuario():
    if not request.json or not 'nome' in request.json:
        Retorno = {
            'status': '99',
            'statusMensagem': 'Erro. Json inválido'
        }
        return json.dumps(Retorno)
    
    arquivo = open(baseDeDados)
    dados = json.load(arquivo)

    if len(dados['Usuarios']) == 0:
        idInsercao = 1 
    else:
        idInsercao = int(dados['Usuarios'][-1]['id']) + 1 # soma 1 no id do ultimo elemento
    dados['Usuarios'].append({
        "id": idInsercao, 
        "nome": request.json['nome']  
    })
    arquivo.close()
    escritaArquivo = open(baseDeDados,'w')
    json.dump(dados,escritaArquivo)
    Retorno = {
            'status': '10',
            'statusMensagem': 'Sucesso',
            'idInserido': idInsercao
    }
    return json.dumps(Retorno)

@app.route('/usuario/',methods = ['PUT'])
def atualizaUsuario():
    if not request.json or not 'nome' or not 'id' in request.json:
        Retorno = {
            'status': '99',
            'statusMensagem': 'Erro. Json inválido'
        }
        return json.dumps(Retorno)
    
    arquivo = open(baseDeDados)
    dados = json.load(arquivo)
    
    indice = int(request.json['id']) - 1
    dados['Usuarios'][indice]['nome'] = request.json['nome']  
    arquivo.close()

    escritaArquivo = open(baseDeDados,'w')
    json.dump(dados,escritaArquivo)
    Retorno = {
            'status': '10',
            'statusMensagem': 'Sucesso',
            'idAtualizado': int(request.json['id']) 
    }

    return json.dumps(Retorno)

@app.route('/usuario/',methods = ['GET'])
def listaUsuarios():
    arquivo = open(baseDeDados)
    dados = json.load(arquivo)
    return dados

@app.route('/usuario/',methods = ['DELETE'])
def deletaUsuario():
    if not request.json or not 'id' in request.json:
        Retorno = {
            'status': '99',
            'statusMensagem': 'Erro. Json inválido'
        }
        return json.dumps(Retorno)
    
    idParaRemover = int(request.json['id'])
    arquivo = open(baseDeDados)
    dados = json.load(arquivo)
    arquivo.close()

    dados['Usuarios'] = [usuario for usuario in dados['Usuarios'] if not(usuario['id'] == idParaRemover )]
    
    escritaArquivo = open(baseDeDados,'w')
    json.dump(dados,escritaArquivo)
    Retorno = {
            'status': '10',
            'statusMensagem': 'Sucesso',
            'idRemovido': idParaRemover
    }

    return json.dumps(Retorno)



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=105)